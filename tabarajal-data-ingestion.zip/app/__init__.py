"""GenWeatherAPI application package."""
