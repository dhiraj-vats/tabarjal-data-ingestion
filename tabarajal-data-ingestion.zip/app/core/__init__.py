"""Core configuration and infrastructure."""
